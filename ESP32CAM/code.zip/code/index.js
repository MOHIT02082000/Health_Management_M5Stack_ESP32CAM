const firebaseConfig = {
  apiKey: "AIzaSyAdOmIxRhe3DuGSR_YU-RsiQVFoQqQaUWA",
  authDomain: "healthdata0.firebaseapp.com",
  databaseURL: "https://healthdata0-default-rtdb.firebaseio.com",
  projectId: "healthdata0",
  storageBucket: "healthdata0.appspot.com",
  messagingSenderId: "451836957271",
  appId: "1:451836957271:web:c946830a688f9477504912",
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const dbRef = firebase.database().ref();
const image = dbRef.child("image_data");
const sensor = dbRef.child("sensor_data");
let cnt = 0;
let maskCount = 0;
let noMaskCount = 0;
const table = document.getElementById("table");
const total = document.getElementById("number");
const mask = document.getElementById("mask");
const nomask = document.getElementById("nomask");
const img = document.getElementById("img");
const data = document.getElementById("data");
var images = [];
var datas = [];
image.on("child_added", (snap) => {
  cnt = cnt + 1;
  total.innerHTML = `${cnt} Checkups`;
  let imgdata = snap.val();
  let strr = imgdata.data;
  code = strr.split(",");
  images.push(code[2]);
});
sensor.on("child_added", (snap) => {
  const user = snap.val();
  datas.push({
    status: user.status,
    temp: user.temperature,
    heart: user.heart,
    time: user.time,
  });
  if (user.status == "No Mask") {
    noMaskCount = noMaskCount + 1;
  } else {
    maskCount = maskCount + 1;
  }
  mask.innerHTML = maskCount;
  nomask.innerHTML = noMaskCount;
});
setTimeout(() => {
  for (let i = 0; i < images.length; i++) {
    table.insertAdjacentHTML(
      "afterbegin",
      `
    <div class='container'>
    <div class='card profile'>
    <div class='inner'>
      <img class="icon" src="data:image/jpeg;base64,${images[i]}" alt="mask">
      <div class='title'>
        <div class='text'>User</div>
      </div>
      <div class='time'>${datas[i].time}</div>
    </div>
  </div>
    <div class='card heart'>
    <div class='inner'>
      <div class="icon"><i class="fa-solid fa-heart-pulse fa-4x"></i></div>
      <div class='title'>
        <div class='text'>HeartPulse</div>
      </div>
      <div class='number'>${datas[i].heart}</div>
      <div class='measure'>BPM</div>
    </div>
  </div>
  <div class='card temp'>
    <div class='inner'>
      <div class='icon'></div>
      <div class='title'>
        <div class='text'>TEMPERATURE</div>
      </div>
      <div class='number'>${datas[i].temp}</div>
      <div class='measure'>Farenite</div>
    </div>
  </div>
  <div class='card status ${datas[i].status}'>
    <div class='inner'>
      <div class='icon'><i class="fa-solid fa-mask-face fa-4x"></i></div>
      <div class='title'>
        <div class='text'>Status</div>
      </div>
      <div class='state '>${datas[i].status}</div>
    </div>
  </div>
</div>`
    );
  }
}, 5000);
